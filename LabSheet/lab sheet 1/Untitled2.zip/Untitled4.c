#include<stdio.h>
int main()
{
	printf("\"Hello\"\n");
	printf("what are you doing?\n");
	printf("'my first day'\n");
}