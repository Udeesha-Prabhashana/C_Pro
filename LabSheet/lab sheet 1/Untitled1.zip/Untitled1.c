#include<stdio.h>
int main()
{
	printf("Name: Udeesha Prabhashana\n");
	printf("Index number: 211091\n");
	printf("Address: Kospalawaththa,Hena,Devinuwara\n");
	printf("Date of Birth: 06.01.2001");
}

