#include<stdio.h>
int main()
{
	char first= 'A';
	char second= 'C';
	char third='T';
	int age= 3;
	printf("how old is your %c%c%c?\n",second,first,third);
	printf("%d year",age);
}