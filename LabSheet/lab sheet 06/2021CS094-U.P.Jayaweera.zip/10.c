#include<stdio.h>
int main()
{
	char str[100], *p;
	int c_vwls=0, c_con=0;
	printf("Enter the string : ");
	scanf("%s",str);
	
	p=str;
	
	while(*p != '\0')
	{
		if(*p=='a' || *p=='e' || *p=='i' || *p=='o' || *p=='u')
		  c_vwls++;
	
    	else if(*p>= 'a' && *p<= 'z')
	      c_con++;
	      
	    p++;
	}
	
	printf(" The count of vowels : %d\n The count of consonants : %d",c_vwls, c_con);
}