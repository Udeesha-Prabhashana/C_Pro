#include<stdio.h>
int main()
{
	int a, b, addition;
	int *p, *q;
	p=&a;
	q=&b;
	
	printf("Enter the values to be added : \n");
	scanf("%d %d",&a, &b);
	
	addition = *p + *q;
	
	printf("The addition is : %d ", addition);
	
	return 0;
}