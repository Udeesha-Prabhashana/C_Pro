#include<stdio.h>
#include<stdlib.h>

int main()
{
	int n,i,x;
	printf("Enter the size of the array : ");
	scanf("%d",&n);
	
	int arr[n];
	printf("Enter the elements : \n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	
	int *p = (int *)malloc(n*sizeof(int));
	
	x=arr[0];
	for(i=0;i<n;i++)
	{
			if(p==NULL)
	  {
		printf("Memory Error\n");
  	  }
	
	  else
	  {
		p=&arr[i];
		
		if(*p>x)
		{
			x=*p;
		}
	  }
	}
	
	printf("The largest element in the array is %d",x);


}