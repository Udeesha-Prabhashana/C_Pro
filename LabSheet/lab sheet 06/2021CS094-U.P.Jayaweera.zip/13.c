#include<stdio.h>
int main()
{
	int  n, i, *p;
	
	printf("Enter the size of the array : ");
	scanf("%d",&n);
	
	int arr[n];
	printf("Enter the elements : \n");
	
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	
	for(i=n-1;i>=0;i--)
	{
		p=&arr[i];
		printf("\t%d",*p);
	}
}