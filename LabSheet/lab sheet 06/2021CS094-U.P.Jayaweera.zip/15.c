#include<stdio.h>
int main()
{
	char letter, *p;
	
	letter= 'a';
	p=&letter;
	
	while(*p>='a' && *p<='z')
	{
		printf("%c\t",*p);
		letter++;
	}
	return 0;
}