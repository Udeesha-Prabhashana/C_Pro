#include<stdio.h>
int main()
{
	int n, i, j, x, *p;
	
	printf("Enter the size of the array : ");
	scanf("%d",&n);
	
	int arr[n];
	for(i=0;i<n;i++)
	{
		p=&arr[i];
		printf("Enter the element : ");
		scanf("%d",p);
	}
	
	for(i=0;i<n;i++)
	{
	   for(j=i+1;j<n;j++)
	   {
	   	if(arr[i]>arr[j])
	   	{
	   		p=&arr[i];
	   		 x=*p;
	   		 *p=arr[j];
	   		 arr[j]=x;
		   }
	   }
	}
	
	printf("Sorting the array in ascending order\n");
	for(i=0;i<n;i++)
	{
		p=&arr[i];
		printf("%d\t",*p);
	}
	
	return 0;
	
}