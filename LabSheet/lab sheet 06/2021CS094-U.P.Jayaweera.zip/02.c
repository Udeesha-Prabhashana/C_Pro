#include<stdio.h>
int addition(int* a, int * b)
{
  return (*a + *b);	
}
int main()
{
	int a,b,sum;
	int *p;
	
	printf("Enter the values to be added : ");
	scanf("%d %d",&a, &b);
	
    sum = addition(&a, &b);
	printf("Addition is : %d ",sum);
}