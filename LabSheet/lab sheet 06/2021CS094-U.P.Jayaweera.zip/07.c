#include<stdio.h>

void swamp(char *p, char *q)
{
	char tmp;
	tmp= *q;
	*q= *p;
   	*p=tmp;
		
}

int main()
{
	char str[100];
	int i, j;
	
	printf("Enter the string : ");
	scanf("%s",&str);
	
	printf("Enter the indexes of the elements to be swamped : ");
	scanf("%d %d",&i, &j);
	
	swamp(&str[i], &str[j]);
	
	printf("%s",str);
	
	return 0;
	
}