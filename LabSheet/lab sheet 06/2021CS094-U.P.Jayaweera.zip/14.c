#include<stdio.h>
int main()
{
	int i,j, count=0;
	char str[100], rev[100], *p;
	printf("Enter the string : ");
	scanf("%s",str);
	
	p=str;
	
	while(*p !='\0')
	{
	  count++;
	  p++;
	}
	j= count-1;
	
	for(i=0;i<count;i++)
	{
	    p=&rev[i];
	    *p=str[j];
	   	j--;
	
	}
	
	printf("String After Reverse : %s",rev);
}