#include<stdio.h>
int main()
{
	int n;
	
	printf("Enter the size of the array : \n");
	scanf("%d",&n);
	
	int i, arr[n] ,*p;
	
	for(i=0;i<n;i++)
	{
		p=&arr[i];
		printf("Enter the element : ");
		scanf("%d",p);
	}
	
	for(i=0;i<n;i++)
	{
		p=&arr[i];
		printf("arr[%d]=%d\n",i,*p);
	}
	
	return 0;
}