#include<stdio.h>
int main()
{
	int a, b, *p;
	
	printf("Enter the values : ");
	scanf("%d %d",&a, &b);
	
	if(a>b)
	 p=&a;
	
	else
	 p=&b;
	 
	printf("The maximum number is : %d",*p);
}