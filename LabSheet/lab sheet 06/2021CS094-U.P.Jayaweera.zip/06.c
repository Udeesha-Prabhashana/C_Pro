#include<stdio.h>
int main()
{
	int count =0;
	char string[100], *p;
	
	printf("Enter the string : ");
	scanf("%s",string);
	
	p=string;
	
	while(*p!='\0')
	{
		count++;
		p++;
	}
	
	printf("The length of the string is %d",count);
	
	return 0;
}