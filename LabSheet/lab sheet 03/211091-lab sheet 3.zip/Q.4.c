#include<stdio.h>
void main() 
{
	int a;
	printf("Enter the number:");
	scanf("%d",&a);
	if(a==1){
		printf("\"ONE\"");
		}
	else
	  if(a==2){
		printf("\"TWO\"");
		}
	else
	if(a==3){
		printf("\"THREE\"");
		}
	else
	if(a==4){
		printf("\"FOUR\"");
		}
	else
	if(a==5){
		printf("\"FIVE\"");
		}	
	else
	if(a==6){
		printf("\"SIX\"");
		}
	else
	if(a==7){
		printf("\"SEVEN\"");
		}	
	else
	if(a==8){
		printf("\"EIGHT\"");
		}
	else
	if(a==9){
		printf("\"NINE\"");
		}
	else
	if(a==10){
		printf("\"TEN\"");
		}				
				
}