#include <stdio.h>
#include <stdlib.h>

void incriment() {
	int num;
        printf("Enter a number: ");
        scanf("%d",&num);

        while (1)
        {
            if (num%9==0) {
                num=0;
		break;
            }
            else
                printf("%d\n",num++);
        }
}


int main(){
    incriment();
    return 0;
}
