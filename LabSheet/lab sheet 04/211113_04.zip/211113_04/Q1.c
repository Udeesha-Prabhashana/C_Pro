#include<stdio.h>

float addition(float n1, float n2) {
	return n1+n2;
}


int main(){

	float n1, n2, sum;

	printf("Enter First number: ");
	scanf("%f", &n1);

	printf("Enter Second number: ");
	scanf("%f", &n2);

	sum = addition(n1, n2);
	printf("Sun: %.2f\n", sum);

	return 0;
}
