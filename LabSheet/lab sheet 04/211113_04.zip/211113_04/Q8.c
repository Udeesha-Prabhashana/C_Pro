#include<stdio.h>



int getGCD(int n1, int n2, int divisor){
/*
	char isGCDFound='f';
	for(int i=divisor; i>0; i--){
		if(n1%i==0 && n2%i==0){
			divisor=i;
			isGCDFound='t';
			break;
		}
	}

	if(isGCDFound=='t')
		return divisor;
	else
		return 0;
*/
	
	if(n1%divisor==0 && n2%divisor==0)
		return divisor;
	else
		getGCD(n1, n2, divisor-1);


}



int main() {
	int n1, n2, gcd, divisor;

	printf("Enter number 1: ");
	scanf("%d", &n1);
	
	printf("Enter number 2: ");
	scanf("%d", &n2);

	if(n1>n2)
		divisor=n2;
	else
		divisor=n1;
	gcd = getGCD(n1, n2, divisor);
	
	printf("G.C.D of %d & %d is: %d \n", n1, n2, gcd);
}
