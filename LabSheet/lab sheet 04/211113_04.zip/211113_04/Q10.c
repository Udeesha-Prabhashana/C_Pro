#include<stdio.h>

int calcFactorial(int number, int counter, int factorial){
	if(counter==number+1)
		return 1;
	else{
		factorial = counter*factorial;
		printf("Factorial of %d is: %d \n", counter, factorial);
		return calcFactorial(number, counter+1, factorial);
	}
}




int main(){

	int number;

	printf("Enter a number: ");
	scanf("%d", &number);

	calcFactorial(number, 1, 1);

}
