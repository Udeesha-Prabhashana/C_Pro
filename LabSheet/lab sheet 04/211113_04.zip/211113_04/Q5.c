#include<stdio.h>
#include<time.h>
#include<stdlib.h>

#define ROCK 1
#define PAPER 2
#define SCISSOR 3


/*
1 - ROCK
2 - PAPER
3 -SCISSORS
*/

int generateRand(){
	srand(time(0));
	return rand()%3 +1;
}


/*
user, computer integer between 1-3
return: 1 if computer wins, 0 if user wins, -1 if draw
*/
int getWinner(int user, int computer){
	if(user==computer)
		return -1;
	else if(computer==ROCK){
		if(user==PAPER)
			return 0;
		else if(user==SCISSOR)
			return 1;
	}
	else if(computer==PAPER){
		if(user==ROCK)
			return  1;
		else if(user==SCISSOR)
			return  0;
	}
	else if(computer==SCISSOR){
		if(user==ROCK)
			return 0;
		else if(user==PAPER)
			return 1;
	}
}






int main(){
	int userChoice, computerChoice, winner;
	char exit='f';

	while(exit=='f'){
		printf("\n\nEnter your choice. \n1 - ROCK\t2 - PAPER \n3 - SCISSOR\tAny Other - Exis \nInput: ");
		scanf("%d", &userChoice);

		computerChoice = generateRand();
		printf("Computer's choice: %d \n", computerChoice);
		winner = getWinner(userChoice, computerChoice); //1 if computer wins. 0 if user wins. -1 if draw

		switch(winner){
			case -1:
				printf("Result: Draw \n");
				break;
			case 0:
				printf("Result: You Win!!! \n");
				break;
			case 1:
				printf("Result: Computer Wins \n");
				break;
			default:
				exit='t';
				printf("Thanks for playing... \n");
				break;
		}
	}

	return 0;
}
