#include<stdio.h>

float getPredictedScore(float currentRR, int nOvers, float higherRR){
	if(higherRR==0)
		return (int)(currentRR*20);
	else
		return (int)((currentRR*nOvers) + (higherRR*(20-nOvers)));
}



int getHigherRR(float currentRR) {

	if (currentRR<0)
		return (int)currentRR;
	else
		return (int)(currentRR+1);
}



int main(){

	int nOvers, predictedScore;
	float currentRR, higherRR;

	printf("Enter Number of overs played: ");
	scanf("%d", &nOvers);

	printf("Enter current run rate: ");
	scanf("%f", &currentRR);

	predictedScore = getPredictedScore(currentRR, nOvers, 0);
	printf("Predicted Score for %.2f = %d \n", currentRR, predictedScore);

	for(int i=1; i<4; i++) {
		higherRR = getHigherRR(currentRR+i);
		predictedScore = getPredictedScore(currentRR, nOvers, higherRR);
		printf("Predicted Score for %.2f = %d \n", higherRR, predictedScore);
	}

	return 0;

}
