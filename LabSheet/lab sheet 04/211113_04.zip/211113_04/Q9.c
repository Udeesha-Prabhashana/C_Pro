#include<stdio.h>



int addPowers(int end, int value, int counter){
	if(counter>end)
		return 0;
	else {
		value = counter*counter;
		return 	value + addPowers(end, value, counter+1);
	}
}




int main(){

	int a, b, result;

	printf("Enter number 1: ");
	scanf("%d", &a);

	printf("Enter number 2: ");
	scanf("%d", &b);
	
	if(a>b)
		result = addPowers(a, b, b);
	else
		result = addPowers(b, a, a);

	printf("Additions of Squareds: %d \n", result);
	return 0;
}
