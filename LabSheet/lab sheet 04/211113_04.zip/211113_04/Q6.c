#include<stdio.h>




int calculator(int n, int r){
	if(r==0 || n==r)
		return 1;
	else
		return calculator(n-1, r) + calculator(n-1, r-1);

}



int main(){
	int n, r, result;

	printf("Enter n: ");
	scanf("%d", &n);

	printf("Enter r: ");
	scanf("%d", &r);

	result = calculator(n, r);
	printf("Result: %d \n", result);

	return 0;
}
