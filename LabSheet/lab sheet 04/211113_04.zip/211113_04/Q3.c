#include<stdio.h>



float calculateArea(float length) {
	return length*length*6;
}



float calculateVolume(float length){
	return length*length*length;
}




int main(){

	float area, volume, sideLength;

	printf("Enter length of a side: ");
	scanf("%f", &sideLength);

	area = calculateArea(sideLength);
	volume = calculateVolume(sideLength);

	printf("Area: %.2f \n", area);
	printf("Volume: %.2f \n", volume);

	return 0;

}
