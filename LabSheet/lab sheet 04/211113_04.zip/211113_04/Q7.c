#include<stdio.h>




int getDataPart(int idNo) {
	return idNo/10000;
}



int printMonth(int dataDigits) {
	int dateDigits = dataDigits%1000;
	int date;

	if(dateDigits>500)
		dateDigits = dateDigits-500;

	if(dateDigits<=31){
                date = dateDigits;
                printf("January");

        }else if(32<dateDigits && dateDigits<=60){
                date =dateDigits-31;
                printf("February");
        }
	else if(61<dateDigits && dateDigits<=91){
                date =dateDigits-60;
                printf("march");
        }
	else if(92<dateDigits&& dateDigits<=120){
                date = dateDigits - 91;
                printf("April");
        }
	else if(121<dateDigits && dateDigits<=151){
                date = dateDigits-120;
                printf("May");
        }
	else if(152<dateDigits&& dateDigits<=181){
                date = dateDigits-151;
                printf("June");
        }
	else if(182<dateDigits && dateDigits<=213){
                date = dateDigits-181;
                printf("July");
	}
	else if(214<dateDigits && dateDigits<=244){
                date = dateDigits-213;
                printf("August");
        }
	else if(245<dateDigits && dateDigits<=274){
                date= dateDigits-244;
                printf("September");
        }
	else if(275<dateDigits && dateDigits<=304){
                date=dateDigits-274;
                printf("October");
        }
	else if(305<dateDigits && dateDigits<=335){
                date = dateDigits- 304;
                printf("November");
        }
	else{
                date = dateDigits-335;
                printf("December");
        }

	printf(" %d \n",date );
	return date;
}




void printYear(int dataDigits){
	int yearDigits = dataDigits/1000;

	printf("19%d\n", yearDigits);	
}




int main(){

	int idNo, dataDigits;

	printf("Enter your NIC number: ");
	scanf("%d", &idNo);

	dataDigits = getDataPart(idNo);

	printMonth(dataDigits);
	printYear(dataDigits);

	return 0;
}
