#include <stdio.h>
#include <stdlib.h>
int count=0;
void increment(){
    if(count==8){
        count=0;
    }else{
    ++count;
    }
}
int main()
{

}