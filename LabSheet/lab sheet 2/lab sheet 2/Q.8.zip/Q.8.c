#include<stdio.h>
int main()
{
	float a=3.2, b=10.1;
	printf("volume of  cylinder=%f",3.14*3.2*3.2*10.1);
	return 0;
}