#include<stdio.h>
int main()
{
	int m=40,n=20,o=20,p=30;
	printf("1. %d\n",m>n && m !=0);
	printf("2. %d\n",o>p || p!=20);
	printf("2. %d\n",!(m>n && m !=0));
	return 0;
}