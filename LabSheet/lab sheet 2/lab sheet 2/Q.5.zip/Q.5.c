#include<stdio.h>
int main()
{
	float X= 1.3,N= 5;
   printf("%.2f",pow(X,N));	
}