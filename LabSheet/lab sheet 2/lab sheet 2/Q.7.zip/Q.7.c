#include<stdio.h>
int main()
{
	int r1=7, r2=5;
	printf("surface area=%f",3.14*(r1*r1-r2*r2));
	return 0;
}