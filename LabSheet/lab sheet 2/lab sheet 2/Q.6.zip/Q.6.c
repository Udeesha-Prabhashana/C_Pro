#include<stdio.h>
int main()
{
	float r=5.4;
	printf("%f",3.14*r*r);
	return 0;
}