#include<stdio.h>
int main()
{
	float a=3.2, b=10.1;
	printf("surface area=%f",2*3.14*a*b);
	return 0;
}